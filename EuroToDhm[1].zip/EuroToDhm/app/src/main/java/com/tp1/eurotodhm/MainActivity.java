package com.tp1.eurotodhm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculateMontant(View view){
        EditText ed = (EditText) findViewById(R.id._in1);
        TextView rslt = (TextView) findViewById(R.id._result);
        int montantEuro, montantDhm;
        montantEuro = Integer.parseInt(ed.getText().toString());
        montantDhm = (int) 10.78 * montantEuro;
        String x = ""+montantDhm;
        rslt.setText(x);
    }
}
