package com.example.tp3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.system.ErrnoException;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText name_city;
    private ListView listview;
    List<MeteoItem> data = new ArrayList<>();
    private MeteoListModal modal;
    public ImageButton buttonOk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name_city = findViewById(R.id.name_city);
        listview = findViewById(R.id.listview);
        buttonOk = findViewById(R.id.Button_search);
        modal = new MeteoListModal(getApplicationContext(), R.layout.meteo_description, data);
        listview.setAdapter(modal);


    buttonOk.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void onClick (View v){
        Log.i("MyLog", "......");
        data.clear();
        modal.notifyDataSetChanged();
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String ville = name_city.getText().toString();
        Log.i("MyLog", ville);
        String url = "https://samples.openweathermap.org/data/2.5/forecast?q="+ville +"&appid=6d0758110947c8fb01d27dee8c3440b8";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.i("MyLOg", "----------------");
                        Log.i("MyLog", response);
                        List<MeteoItem> meteoItems = new ArrayList<>();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("list");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                MeteoItem meteoItem = new MeteoItem();
                                JSONObject d = jsonArray.getJSONObject(i);
                                Date date = new Date(d.getLong("dt") * 1000);
                                 SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm");
                                String dateString = sdf.format(date);
                                JSONObject main = d.getJSONObject("main");
                                JSONArray weather = d.getJSONArray("weather");
                                int tempMin = (int) (main.getDouble("temp_min") - 273.15);
                                int tempMax = (int) (main.getDouble("temp_max") - 273.15);
                                int pression = main.getInt("pressure");
                                int humidity = main.getInt("humidity");
                                meteoItem.tempMax = tempMax;
                                meteoItem.tempMin = tempMin;
                                meteoItem.pression = pression;
                                meteoItem.humidite = humidity;
                                meteoItem.date = dateString;
                                meteoItem.image = weather.getJSONObject(0).getString("main");
                                data.add(meteoItem);
                            }
                            modal.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("MyLog", "Connection Faild");
            }
        });
        queue.add(stringRequest);
    }

    });
}
}
