package com.example.tp3;

import android.content.Context;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

//public class MeteoListModel  {
////    private List<MeteoItem> listItems;
////    private  int resource;
////    public static Map<String,Integer> images=new HashMap<>();
////    static {
////        images.put("clear",R.drawable.sun);
////        images.put("Clouds",R.drawable.sun);
////        images.put("Rain",R.drawable.sun);
////        images.put("thunderstormspng",R.drawable.sun);
////
////    }
////    public MeteoListModel(@NonNull Context context, int resource, List<MeteoItem>){
////        super(context,resource,data);
////
////    }
//
//
//
//
//}
