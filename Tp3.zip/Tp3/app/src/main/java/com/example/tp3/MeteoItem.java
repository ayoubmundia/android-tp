package com.example.tp3;

class MeteoItem {
    public int tempMax;
    public int tempMin;
    public int pression;
    public int humidite;
    public String image;
    public String date;


}
