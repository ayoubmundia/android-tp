package com.tp2.guesswhat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public int random;
    public LinearLayout ll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        View overlay = findViewById(R.id.main);

        ll = (LinearLayout) findViewById(R.id._feedsVer);
        overlay.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE);

        Random randomGenerator = new Random();
        this.random = randomGenerator.nextInt(1000) + 1;
        String text = ""+this.random;
        Toast.makeText(this,text,Toast.LENGTH_LONG).show();
    }

    public void guessFunction(View view) {
        TextView rslt = (TextView) findViewById(R.id._message);
        EditText inp = (EditText) findViewById(R.id._inNum);

        String checkInt = inp.getText().toString();
        if (checkInt.matches("")) {
            rslt.setText("Bsala hadi");
            return;
        }

        int userGuessing;
        userGuessing = Integer.parseInt(inp.getText().toString());

        if(valueAbsolu(userGuessing , this.random) ==0){
            rslt.setText("We We We");
        }
        else if(valueAbsolu(userGuessing , this.random) <=10){
            rslt.setText("Ser Ser Ser");
        }else if(valueAbsolu(userGuessing , this.random) <=50){
            rslt.setText("YES YES Continue");
        }else if(valueAbsolu(userGuessing , this.random) <=100){
            rslt.setText("JUST TRY AGAIN");
        }else if(valueAbsolu(userGuessing , this.random) <=500){
            rslt.setText("5/5");
        }else if(valueAbsolu(userGuessing , this.random) <= 700){
            rslt.setText("Such a clever boy");
        }
        else{
            rslt.setText("HHHHHH");
        }

        ConstraintLayout cube = new ConstraintLayout(this);
        TextView msg = (TextView) new TextView(this);

        msg.setPadding(5,0,0,0);
        if(userGuessing == this.random){
            msg.setText("NADI");
            msg.setTextColor(Color.YELLOW);
        }else if(userGuessing > this.random){
            msg.setText(userGuessing+" => DOWN");
            msg.setTextColor(Color.RED);

        }else if(userGuessing < this.random){
            msg.setText(userGuessing+" => UP");
            msg.setTextColor(Color.MAGENTA);
        }


        cube.addView(msg);
        ll.addView(cube);
        ll.invalidate();
    }

    public int valueAbsolu(int i, int j){
        int k = i - j;
        if (k<0){
            k = k * -1;
        }
        return k;
    }

    @Override
    protected void onResume() {
        super.onResume();

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

}
